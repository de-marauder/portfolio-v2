"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { motion } from "framer-motion"
import { Github, Linkedin, Twitter, Mail, Download, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ThemeToggle } from "@/components/theme-toggle"
import { ParticlesContainer } from "@/components/particles-container"
import { ProjectCard } from "@/components/project-card"
import { SkillBadge } from "@/components/skill-badge"
import { Timeline } from "@/components/timeline"

export default function Home() {
  const [activeSection, setActiveSection] = useState("home")
  const [scrollY, setScrollY] = useState(0)

  useEffect(() => {
    const handleScroll = () => {
      setScrollY(window.scrollY)

      // Update active section based on scroll position
      const sections = ["home", "about", "skills", "projects", "experience", "contact"]

      for (const section of sections) {
        const element = document.getElementById(section)
        if (element) {
          const rect = element.getBoundingClientRect()
          if (rect.top <= 100 && rect.bottom >= 100) {
            setActiveSection(section)
            break
          }
        }
      }
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const navItems = [
    { name: "Home", href: "#home" },
    { name: "About", href: "#about" },
    { name: "Skills", href: "#skills" },
    { name: "Projects", href: "#projects" },
    { name: "Experience", href: "#experience" },
    { name: "Contact", href: "#contact" },
  ]

  const skills = {
    frontend: ["React", "Next.js", "TypeScript", "JavaScript", "HTML/CSS", "Tailwind CSS"],
    backend: ["Node.js", "Express", "MongoDB", "PostgreSQL", "REST API", "GraphQL"],
    devops: ["AWS", "Docker", "Kubernetes", "CI/CD", "Terraform", "Linux"],
  }

  const projects = [
    {
      title: "Project One",
      description: "A full-stack application built with Next.js, TypeScript, and MongoDB.",
      image: "/placeholder.svg?height=400&width=600",
      tags: ["Next.js", "TypeScript", "MongoDB", "Tailwind CSS"],
      github: "https://github.com",
      demo: "https://example.com",
    },
    {
      title: "Project Two",
      description: "A DevOps automation tool built with Node.js and Docker.",
      image: "/placeholder.svg?height=400&width=600",
      tags: ["Node.js", "Docker", "AWS", "CI/CD"],
      github: "https://github.com",
      demo: "https://example.com",
    },
    {
      title: "Project Three",
      description: "A real-time dashboard for monitoring Kubernetes clusters.",
      image: "/placeholder.svg?height=400&width=600",
      tags: ["React", "Kubernetes", "WebSockets", "Charts"],
      github: "https://github.com",
      demo: "https://example.com",
    },
  ]

  const experiences = [
    {
      title: "Senior DevOps Engineer",
      company: "Tech Company",
      period: "Jan 2022 - Present",
      description: "Led the implementation of CI/CD pipelines and Kubernetes infrastructure.",
      skills: ["AWS", "Kubernetes", "Terraform", "CI/CD"],
    },
    {
      title: "Software Engineer",
      company: "Startup Inc.",
      period: "Mar 2020 - Dec 2021",
      description: "Developed full-stack applications using React, Node.js, and MongoDB.",
      skills: ["React", "Node.js", "MongoDB", "TypeScript"],
    },
    {
      title: "Junior Developer",
      company: "First Company",
      period: "Jun 2018 - Feb 2020",
      description: "Built and maintained web applications using JavaScript and PHP.",
      skills: ["JavaScript", "PHP", "MySQL", "HTML/CSS"],
    },
  ]

  return (
    <div className="min-h-screen bg-background">
      {/* Particles Background */}
      <div className="fixed inset-0 -z-10">
        <ParticlesContainer />
      </div>

      {/* Header */}
      <header
        className={`fixed top-0 w-full z-50 transition-all duration-300 ${
          scrollY > 50 ? "bg-background/80 backdrop-blur-md shadow-sm" : "bg-transparent"
        }`}
      >
        <div className="container flex items-center justify-between h-16 px-4 md:px-6">
          <Link href="#home" className="flex items-center space-x-2">
            <div className="relative w-8 h-8">
              <div className="absolute inset-0 bg-gradient-to-br from-cyan-400 to-purple-600 rounded-md"></div>
              <div className="absolute inset-[2px] bg-background rounded-md flex items-center justify-center">
                <span className="font-bold text-lg">OE</span>
              </div>
            </div>
            <span className="font-bold text-lg hidden sm:inline-block">Obiajulu Ezike</span>
          </Link>

          <nav className="hidden md:flex items-center space-x-1">
            {navItems.map((item) => (
              <Link
                key={item.name}
                href={item.href}
                className={`px-3 py-2 text-sm rounded-md transition-colors ${
                  activeSection === item.name.toLowerCase()
                    ? "text-primary font-medium"
                    : "text-muted-foreground hover:text-foreground hover:bg-accent"
                }`}
              >
                {item.name}
              </Link>
            ))}
          </nav>

          <div className="flex items-center space-x-2">
            <ThemeToggle />
            <Button
              variant="default"
              size="sm"
              className="hidden sm:flex"
              onClick={() => {
                document.getElementById("contact")?.scrollIntoView({ behavior: "smooth" })
              }}
            >
              <Mail className="mr-2 h-4 w-4" />
              Contact Me
            </Button>
            <Button variant="outline" size="icon" className="md:hidden">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="h-5 w-5"
              >
                <line x1="4" x2="20" y1="12" y2="12" />
                <line x1="4" x2="20" y1="6" y2="6" />
                <line x1="4" x2="20" y1="18" y2="18" />
              </svg>
            </Button>
          </div>
        </div>
      </header>

      <main className="container px-4 md:px-6 pt-16">
        {/* Hero Section */}
        <section id="home" className="min-h-[90vh] flex flex-col items-center justify-center py-20">
          <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center max-w-6xl mx-auto">
            <div className="flex flex-col justify-center space-y-4">
              <div className="space-y-2">
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5 }}
                >
                  <Badge variant="outline" className="text-sm px-3 py-1 border-primary/50 text-primary">
                    Software & DevOps Engineer
                  </Badge>
                </motion.div>
                <motion.h1
                  className="text-4xl font-bold tracking-tighter sm:text-5xl md:text-6xl bg-clip-text text-transparent bg-gradient-to-r from-primary to-purple-500"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.1 }}
                >
                  Obiajulu Ezike
                </motion.h1>
                <motion.p
                  className="max-w-[600px] text-muted-foreground md:text-xl"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.2 }}
                >
                  I build scalable applications and robust infrastructure. Specializing in full-stack development and
                  DevOps automation to deliver high-performance solutions.
                </motion.p>
              </div>
              <motion.div
                className="flex flex-col sm:flex-row gap-3"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.3 }}
              >
                <Button
                  size="lg"
                  className="bg-gradient-to-r from-primary to-purple-600 hover:from-primary/90 hover:to-purple-600/90"
                  onClick={() => {
                    document.getElementById("projects")?.scrollIntoView({ behavior: "smooth" })
                  }}
                >
                  View My Projects
                  <ChevronRight className="ml-2 h-4 w-4" />
                </Button>
                <Button size="lg" variant="outline">
                  <Download className="mr-2 h-4 w-4" />
                  Download Resume
                </Button>
              </motion.div>
              <motion.div
                className="flex items-center gap-4 mt-2"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.4 }}
              >
                <Link
                  href="https://github.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-muted-foreground hover:text-foreground transition-colors"
                >
                  <Github className="h-5 w-5" />
                  <span className="sr-only">GitHub</span>
                </Link>
                <Link
                  href="https://linkedin.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-muted-foreground hover:text-foreground transition-colors"
                >
                  <Linkedin className="h-5 w-5" />
                  <span className="sr-only">LinkedIn</span>
                </Link>
                <Link
                  href="https://twitter.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-muted-foreground hover:text-foreground transition-colors"
                >
                  <Twitter className="h-5 w-5" />
                  <span className="sr-only">Twitter</span>
                </Link>
              </motion.div>
            </div>
            <motion.div
              className="flex justify-center lg:justify-end"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <div className="relative w-[280px] h-[280px] sm:w-[320px] sm:h-[320px]">
                <div className="absolute inset-0 rounded-full bg-gradient-to-br from-primary to-purple-600 opacity-20 blur-2xl"></div>
                <div className="relative w-full h-full rounded-full overflow-hidden border-4 border-background shadow-xl">
                  <Image
                    src="/placeholder.svg?height=400&width=400"
                    alt="Obiajulu Ezike"
                    fill
                    className="object-cover"
                    priority
                  />
                </div>
              </div>
            </motion.div>
          </div>
        </section>

        {/* About Section */}
        <section id="about" className="py-20">
          <div className="max-w-3xl mx-auto">
            <div className="space-y-2 text-center mb-8">
              <Badge variant="outline" className="text-sm px-3 py-1 border-primary/50 text-primary">
                About Me
              </Badge>
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">My Background</h2>
              <p className="text-muted-foreground md:text-lg max-w-[700px] mx-auto">
                Get to know more about my journey, experience, and what drives me as a developer.
              </p>
            </div>
            <Card>
              <CardContent className="p-6 sm:p-8">
                <div className="space-y-4">
                  <p>
                    I'm a passionate Software & DevOps Engineer with over 5 years of experience building and deploying
                    applications. My journey began with web development, which evolved into a deep interest in cloud
                    infrastructure and automation.
                  </p>
                  <p>
                    I specialize in creating scalable applications using modern JavaScript frameworks like React and
                    Next.js, while also implementing robust backend systems with Node.js and various databases. My
                    DevOps expertise includes containerization with Docker, orchestration with Kubernetes, and cloud
                    infrastructure on AWS.
                  </p>
                  <p>
                    What drives me is the challenge of solving complex problems and continuously learning new
                    technologies. I'm particularly interested in system architecture, performance optimization, and
                    creating developer-friendly tools.
                  </p>
                  <p>
                    When I'm not coding, you can find me contributing to open-source projects, writing technical
                    articles, or exploring the latest developments in the tech world.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Skills Section */}
        <section id="skills" className="py-20">
          <div className="max-w-4xl mx-auto">
            <div className="space-y-2 text-center mb-8">
              <Badge variant="outline" className="text-sm px-3 py-1 border-primary/50 text-primary">
                My Expertise
              </Badge>
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Skills & Technologies</h2>
              <p className="text-muted-foreground md:text-lg max-w-[700px] mx-auto">
                The tools and technologies I use to bring projects to life.
              </p>
            </div>
            <Tabs defaultValue="frontend" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="frontend">Frontend</TabsTrigger>
                <TabsTrigger value="backend">Backend</TabsTrigger>
                <TabsTrigger value="devops">DevOps</TabsTrigger>
              </TabsList>
              <TabsContent value="frontend" className="mt-6">
                <Card>
                  <CardContent className="p-6">
                    <div className="flex flex-wrap gap-2">
                      {skills.frontend.map((skill) => (
                        <SkillBadge key={skill} name={skill} />
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              <TabsContent value="backend" className="mt-6">
                <Card>
                  <CardContent className="p-6">
                    <div className="flex flex-wrap gap-2">
                      {skills.backend.map((skill) => (
                        <SkillBadge key={skill} name={skill} />
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              <TabsContent value="devops" className="mt-6">
                <Card>
                  <CardContent className="p-6">
                    <div className="flex flex-wrap gap-2">
                      {skills.devops.map((skill) => (
                        <SkillBadge key={skill} name={skill} />
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </section>

        {/* Projects Section */}
        <section id="projects" className="py-20">
          <div className="max-w-6xl mx-auto">
            <div className="space-y-2 text-center mb-12">
              <Badge variant="outline" className="text-sm px-3 py-1 border-primary/50 text-primary">
                My Work
              </Badge>
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Featured Projects</h2>
              <p className="text-muted-foreground md:text-lg max-w-[700px] mx-auto">
                A selection of my recent work and personal projects.
              </p>
            </div>
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {projects.map((project, index) => (
                <ProjectCard key={index} project={project} />
              ))}
            </div>
            <div className="flex justify-center mt-10">
              <Button
                variant="outline"
                size="lg"
                onClick={() => {
                  // This could link to a dedicated projects page in the future
                  window.open("https://github.com/username", "_blank")
                }}
              >
                View All Projects
                <ChevronRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </div>
        </section>

        {/* Experience Section */}
        <section id="experience" className="py-20">
          <div className="max-w-4xl mx-auto">
            <div className="space-y-2 text-center mb-12">
              <Badge variant="outline" className="text-sm px-3 py-1 border-primary/50 text-primary">
                My Journey
              </Badge>
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Work Experience</h2>
              <p className="text-muted-foreground md:text-lg max-w-[700px] mx-auto">
                My professional background and career milestones.
              </p>
            </div>
            <Timeline experiences={experiences} />
          </div>
        </section>

        {/* Contact Section */}
        <section id="contact" className="py-20">
          <div className="max-w-3xl mx-auto">
            <div className="space-y-2 text-center mb-8">
              <Badge variant="outline" className="text-sm px-3 py-1 border-primary/50 text-primary">
                Get In Touch
              </Badge>
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Contact Me</h2>
              <p className="text-muted-foreground md:text-lg max-w-[700px] mx-auto">
                Have a project in mind or want to discuss opportunities? Let's talk!
              </p>
            </div>
            <Card>
              <CardContent className="p-6 sm:p-8">
                <form className="space-y-6">
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div className="space-y-2">
                      <label htmlFor="name" className="text-sm font-medium">
                        Name
                      </label>
                      <input
                        id="name"
                        placeholder="Your name"
                        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                      />
                    </div>
                    <div className="space-y-2">
                      <label htmlFor="email" className="text-sm font-medium">
                        Email
                      </label>
                      <input
                        id="email"
                        type="email"
                        placeholder="Your email"
                        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label htmlFor="subject" className="text-sm font-medium">
                      Subject
                    </label>
                    <input
                      id="subject"
                      placeholder="Subject"
                      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                    />
                  </div>
                  <div className="space-y-2">
                    <label htmlFor="message" className="text-sm font-medium">
                      Message
                    </label>
                    <textarea
                      id="message"
                      placeholder="Your message"
                      className="flex min-h-[120px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                    />
                  </div>
                  <Button
                    type="submit"
                    className="w-full bg-gradient-to-r from-primary to-purple-600 hover:from-primary/90 hover:to-purple-600/90"
                  >
                    Send Message
                  </Button>
                </form>
              </CardContent>
            </Card>
            <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-4 text-center">
              <Card className="w-full">
                <CardContent className="p-4 flex flex-col items-center">
                  <Mail className="h-6 w-6 text-primary mb-2" />
                  <p className="text-sm">contact@example.com</p>
                </CardContent>
              </Card>
              <Card className="w-full">
                <CardContent className="p-4 flex flex-col items-center">
                  <Linkedin className="h-6 w-6 text-primary mb-2" />
                  <p className="text-sm">linkedin.com/in/username</p>
                </CardContent>
              </Card>
              <Card className="w-full">
                <CardContent className="p-4 flex flex-col items-center">
                  <Github className="h-6 w-6 text-primary mb-2" />
                  <p className="text-sm">github.com/username</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t">
        <div className="container flex flex-col sm:flex-row items-center justify-between py-8 px-4 md:px-6">
          <div className="flex items-center space-x-2">
            <div className="relative w-6 h-6">
              <div className="absolute inset-0 bg-gradient-to-br from-cyan-400 to-purple-600 rounded-md"></div>
              <div className="absolute inset-[2px] bg-background rounded-md flex items-center justify-center">
                <span className="font-bold text-xs">OE</span>
              </div>
            </div>
            <span className="text-sm font-medium">Obiajulu Ezike</span>
          </div>
          <p className="text-sm text-muted-foreground mt-4 sm:mt-0">
            © {new Date().getFullYear()} Obiajulu Ezike. All rights reserved.
          </p>
          <div className="flex items-center space-x-4 mt-4 sm:mt-0">
            <Link
              href="https://github.com"
              target="_blank"
              rel="noopener noreferrer"
              className="text-muted-foreground hover:text-foreground transition-colors"
            >
              <Github className="h-4 w-4" />
              <span className="sr-only">GitHub</span>
            </Link>
            <Link
              href="https://linkedin.com"
              target="_blank"
              rel="noopener noreferrer"
              className="text-muted-foreground hover:text-foreground transition-colors"
            >
              <Linkedin className="h-4 w-4" />
              <span className="sr-only">LinkedIn</span>
            </Link>
            <Link
              href="https://twitter.com"
              target="_blank"
              rel="noopener noreferrer"
              className="text-muted-foreground hover:text-foreground transition-colors"
            >
              <Twitter className="h-4 w-4" />
              <span className="sr-only">Twitter</span>
            </Link>
          </div>
        </div>
      </footer>
    </div>
  )
}
